package test;

public class MainTest {
	public static void main(String[] args) {
		B b=new B("김재원",18,90);
		C c=new C();
		b.run();
		c.run();
	}
}