package test;

public class A {
	int num;
	A(){
		
	}
	A(int num){
		this.num=num;
	}
}
