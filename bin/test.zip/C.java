package test;

public class C extends B{
	void run() {
		System.out.println("C실행중");
	}
}
