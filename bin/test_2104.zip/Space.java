package test_2104;

public class Space {
	String name;
	Space(String name){
		this.name=name;
	}
	public void enterCity() {
		System.out.println("you entered "+name);
	}
}
