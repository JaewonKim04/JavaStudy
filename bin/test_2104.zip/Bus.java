package test_2104;

public class Bus {
	int number;
	public void ride() {
		System.out.println("you ride a bus");
	}
}
